import { useEffect, useState } from 'react';
import { Trophy, Medal, Star, Award } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';

export default function Leaderboard() {
  const [students, setStudents] = useState([]);
  const [topResults, setTopResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('points');

  useEffect(() => {
    fetch('/api/leaderboard')
      .then((r) => r.json())
      .then((data) => {
        setStudents(Array.isArray(data.students) ? data.students : []);
        setTopResults(Array.isArray(data.topResults) ? data.topResults : []);
      })
      .catch(() => setError('فشل تحميل لوحة المتفوقين'))
      .finally(() => setLoading(false));
  }, []);

  const rankIcon = (i) => {
    if (i === 0) return <Trophy className="w-5 h-5 text-amber-500" />;
    if (i === 1) return <Medal className="w-5 h-5 text-stone-400" />;
    if (i === 2) return <Medal className="w-5 h-5 text-amber-700" />;
    return <span className="w-5 text-center text-sm font-bold text-stone-400">{i + 1}</span>;
  };

  const rankBg = (i) => {
    if (i === 0) return 'bg-gradient-to-l from-amber-50 to-orange-50 border-amber-200';
    if (i === 1) return 'bg-stone-100 border-stone-300';
    if (i === 2) return 'bg-orange-50/50 border-orange-100';
    return 'bg-white border-stone-200';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-stone-400/40 mb-4">
          <Trophy className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-stone-900 mb-2">لوحة المتفوقين</h1>
        <p className="text-stone-600">أفضل طلاب English Mastery · Mr. Sherif Atta</p>
      </div>

      <div className="flex justify-center gap-2 mb-8">
        <button
          onClick={() => setTab('points')}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
            tab === 'points' ? 'bg-amber-700 text-white' : 'bg-white border border-stone-300 text-stone-600'
          }`}
        >
          <span className="inline-flex items-center gap-1.5"><Star className="w-4 h-4" /> ترتيب النقاط</span>
        </button>
        <button
          onClick={() => setTab('results')}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
            tab === 'results' ? 'bg-amber-700 text-white' : 'bg-white border border-stone-300 text-stone-600'
          }`}
        >
          <span className="inline-flex items-center gap-1.5"><Award className="w-4 h-4" /> أعلى النتائج</span>
        </button>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : error ? (
        <div className="text-center py-16 text-red-600">{error}</div>
      ) : tab === 'points' ? (
        students.length === 0 ? (
          <div className="text-center py-16 text-stone-500">لا يوجد طلاب بعد — كن أول المتفوقين!</div>
        ) : (
          <div className="space-y-3">
            {students.map((s, i) => (
              <div
                key={s.id}
                className={`flex items-center gap-4 p-4 rounded-2xl border ${rankBg(i)} transition-shadow hover:shadow-sm`}
              >
                <div className="w-10 flex justify-center">{rankIcon(i)}</div>
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-amber-600 to-stone-800 flex items-center justify-center text-white font-bold shrink-0">
                  {(s.full_name || 'ط')[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-stone-900 truncate">{s.full_name || 'طالب'}</div>
                  <div className="text-xs text-stone-500 truncate">{s.email}</div>
                </div>
                <div className="text-left">
                  <div className="text-lg font-black text-amber-700">{s.total_points || 0}</div>
                  <div className="text-xs text-stone-500">نقطة</div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : topResults.length === 0 ? (
        <div className="text-center py-16 text-stone-500">لا توجد نتائج اختبارات بعد</div>
      ) : (
        <div className="space-y-3">
          {topResults.map((r, i) => (
            <div
              key={r.id}
              className={`flex items-center gap-4 p-4 rounded-2xl border ${rankBg(i)}`}
            >
              <div className="w-10 flex justify-center">{rankIcon(i)}</div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-stone-900 truncate">{r.user_name || 'طالب'}</div>
                <div className="text-xs text-stone-500">اختبار #{r.quiz_id} · {r.score}/{r.total_questions}</div>
              </div>
              <div className="text-left">
                <div className="text-lg font-black text-emerald-600">{r.percentage}%</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
