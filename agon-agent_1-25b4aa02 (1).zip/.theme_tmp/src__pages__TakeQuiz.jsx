import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, XCircle, Trophy, RotateCcw } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useAuth } from '../contexts/AuthContext';

export default function TakeQuiz() {
  const { id } = useParams();
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    Promise.all([
      fetch(`/api/quizzes?id=${id}`).then((r) => r.json()),
      fetch(`/api/questions?quiz_id=${id}&hide_answers=true`).then((r) => r.json()),
    ])
      .then(([q, qs]) => {
        if (q.error) throw new Error(q.error);
        setQuiz(q);
        setQuestions(Array.isArray(qs) ? qs : []);
      })
      .catch((e) => setError(e.message || 'فشل التحميل'))
      .finally(() => setLoading(false));
  }, [id, user, navigate]);

  const handleSubmit = async () => {
    if (Object.keys(answers).length < questions.length) {
      if (!confirm('لم تجب على كل الأسئلة. هل تريد التسليم الآن؟')) return;
    }
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch('/api/results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          quiz_id: Number(id),
          user_name: profile?.full_name || user.email,
          answers,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل حفظ النتيجة');
      setResult(data);
      refreshProfile();
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error && !quiz) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-red-600 mb-4">{error}</p>
        <Link to="/quizzes" className="text-amber-700 font-medium">العودة للاختبارات</Link>
      </div>
    );
  }

  if (result) {
    const pct = result.percentage;
    const good = pct >= 70;
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="bg-white rounded-3xl border border-stone-200 shadow-lg p-8 text-center">
          <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center ${
            good ? 'bg-yellow-100' : 'bg-amber-100'
          }`}>
            <Trophy className={`w-10 h-10 ${good ? 'text-emerald-600' : 'text-amber-600'}`} />
          </div>
          <h1 className="text-2xl font-bold text-stone-900 mb-2">انتهى الاختبار!</h1>
          <p className="text-stone-600 mb-6">{quiz?.title_ar || quiz?.title}</p>
          <div className="text-6xl font-black text-amber-700 mb-2">{pct}%</div>
          <p className="text-stone-600 mb-6">
            أحرزت {result.score} من {result.total_questions} أسئلة
          </p>
          <div className="space-y-3 text-right mb-8 max-h-80 overflow-y-auto">
            {questions.map((q, i) => {
              const userAns = answers[q.id];
              const correct = result.correct_answers?.[q.id];
              const isCorrect = userAns === correct;
              return (
                <div key={q.id} className={`p-3 rounded-xl border text-sm ${
                  isCorrect ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'
                }`}>
                  <div className="flex items-start gap-2">
                    {isCorrect ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
                    )}
                    <div>
                      <div className="font-medium text-stone-800">{i + 1}. {q.question_text}</div>
                      <div className="text-stone-600 mt-1">إجابتك: {userAns ? q[`option_${userAns}`] : '—'}</div>
                      {!isCorrect && <div className="text-yellow-900 mt-0.5">الصحيحة: {q[`option_${correct}`]}</div>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/leaderboard" className="px-5 py-2.5 rounded-xl bg-amber-700 text-white font-semibold hover:bg-amber-800">
              لوحة المتفوقين
            </Link>
            <Link to="/quizzes" className="px-5 py-2.5 rounded-xl bg-stone-200 text-stone-700 font-semibold hover:bg-stone-300 flex items-center gap-1">
              <RotateCcw className="w-4 h-4" />
              اختبارات أخرى
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (!questions.length) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center text-stone-500">
        لا توجد أسئلة في هذا الاختبار بعد
        <div className="mt-4"><Link to="/quizzes" className="text-amber-700">العودة</Link></div>
      </div>
    );
  }

  const q = questions[current];
  const options = [
    { key: 'a', text: q.option_a },
    { key: 'b', text: q.option_b },
    { key: 'c', text: q.option_c },
    { key: 'd', text: q.option_d },
  ].filter((o) => o.text);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      <Link to="/quizzes" className="inline-flex items-center gap-1 text-sm text-stone-500 hover:text-amber-700 mb-6">
        <ArrowRight className="w-4 h-4" />
        العودة للاختبارات
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-stone-900">{quiz?.title_ar || quiz?.title}</h1>
        <div className="mt-3 h-2 bg-stone-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-amber-700 rounded-full transition-all"
            style={{ width: `${((current + 1) / questions.length) * 100}%` }}
          />
        </div>
        <p className="text-sm text-stone-500 mt-2">سؤال {current + 1} من {questions.length}</p>
      </div>

      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 md:p-8 mb-6">
        <h2 className="text-xl font-bold text-stone-900 mb-6 leading-relaxed">{q.question_text}</h2>
        <div className="space-y-3">
          {options.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setAnswers({ ...answers, [q.id]: opt.key })}
              className={`w-full text-right p-4 rounded-xl border-2 transition-all ${
                answers[q.id] === opt.key
                  ? 'border-amber-600 bg-amber-50 text-amber-950'
                  : 'border-stone-200 hover:border-stone-300 text-stone-700'
              }`}
            >
              <span className="inline-flex items-center gap-3">
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                  answers[q.id] === opt.key ? 'bg-amber-700 text-white' : 'bg-stone-200 text-stone-600'
                }`}>
                  {opt.key.toUpperCase()}
                </span>
                {opt.text}
              </span>
            </button>
          ))}
        </div>
      </div>

      {error && <p className="text-red-600 text-sm mb-4 text-center">{error}</p>}

      <div className="flex items-center justify-between gap-3">
        <button
          disabled={current === 0}
          onClick={() => setCurrent((c) => c - 1)}
          className="px-5 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-medium disabled:opacity-40 hover:bg-stone-100"
        >
          السابق
        </button>
        {current < questions.length - 1 ? (
          <button
            onClick={() => setCurrent((c) => c + 1)}
            className="px-5 py-2.5 rounded-xl bg-amber-700 text-white font-semibold hover:bg-amber-800"
          >
            التالي
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold hover:bg-emerald-700 disabled:opacity-60"
          >
            {submitting ? 'جاري التسليم...' : 'تسليم الإجابات'}
          </button>
        )}
      </div>
    </div>
  );
}
