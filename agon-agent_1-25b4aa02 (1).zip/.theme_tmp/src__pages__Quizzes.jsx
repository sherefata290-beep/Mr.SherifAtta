import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ClipboardList, Clock, Filter, Play } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useAuth } from '../contexts/AuthContext';

const levelLabels = {
  beginner: { ar: 'مبتدئ', color: 'bg-yellow-100 text-yellow-900' },
  intermediate: { ar: 'متوسط', color: 'bg-stone-200 text-stone-800' },
  advanced: { ar: 'متقدم', color: 'bg-stone-200 text-stone-800' },
};

export default function Quizzes() {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const { user } = useAuth();

  useEffect(() => {
    fetch('/api/quizzes')
      .then((r) => r.json())
      .then((data) => setQuizzes(Array.isArray(data) ? data : []))
      .catch(() => setError('فشل تحميل الاختبارات'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = filter === 'all' ? quizzes : quizzes.filter((q) => q.level === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-stone-900 mb-2">الاختبارات</h1>
        <p className="text-stone-600">اختبر مستواك في اللغة الإنجليزية واحصل على نتائج فورية</p>
      </div>

      <div className="flex items-center gap-2 mb-8 overflow-x-auto">
        <Filter className="w-4 h-4 text-stone-400 shrink-0" />
        {['all', 'beginner', 'intermediate', 'advanced'].map((lv) => (
          <button
            key={lv}
            onClick={() => setFilter(lv)}
            className={`px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              filter === lv
                ? 'bg-amber-700 text-white'
                : 'bg-white border border-stone-300 text-stone-600 hover:bg-stone-50'
            }`}
          >
            {lv === 'all' ? 'الكل' : levelLabels[lv]?.ar || lv}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : error ? (
        <div className="text-center py-16 text-red-600">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-stone-500">لا توجد اختبارات متاحة</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((quiz) => {
            const lvl = levelLabels[quiz.level] || levelLabels.beginner;
            return (
              <div
                key={quiz.id}
                className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 hover:shadow-md transition-shadow flex flex-col"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-stone-600 to-zinc-800 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-white" />
                  </div>
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${lvl.color}`}>{lvl.ar}</span>
                </div>
                <h3 className="font-bold text-stone-900 text-lg mb-1">{quiz.title_ar || quiz.title}</h3>
                <p className="text-sm text-amber-700 mb-2">{quiz.title}</p>
                <p className="text-stone-600 text-sm mb-4 flex-1 line-clamp-3">{quiz.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-stone-200">
                  <span className="flex items-center gap-1 text-xs text-stone-500">
                    <Clock className="w-3.5 h-3.5" />
                    {quiz.duration_minutes || 20} دقيقة
                  </span>
                  {user ? (
                    <Link
                      to={`/quizzes/${quiz.id}`}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-700 text-white text-sm font-semibold hover:bg-amber-800 transition-colors"
                    >
                      <Play className="w-3.5 h-3.5" />
                      ابدأ
                    </Link>
                  ) : (
                    <Link
                      to="/login"
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-stone-200 text-stone-700 text-sm font-semibold hover:bg-stone-300 transition-colors"
                    >
                      سجّل للبدء
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
