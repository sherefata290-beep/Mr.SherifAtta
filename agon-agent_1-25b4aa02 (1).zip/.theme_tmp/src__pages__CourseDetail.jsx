import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Clock, PlayCircle } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';

const levelLabels = {
  beginner: { ar: 'مبتدئ', color: 'bg-yellow-100 text-yellow-900' },
  intermediate: { ar: 'متوسط', color: 'bg-stone-200 text-stone-800' },
  advanced: { ar: 'متقدم', color: 'bg-stone-200 text-stone-800' },
};

export default function CourseDetail() {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [activeLesson, setActiveLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch(`/api/courses?id=${id}`).then((r) => r.json()),
      fetch(`/api/lessons?course_id=${id}`).then((r) => r.json()),
    ])
      .then(([c, l]) => {
        if (c.error) throw new Error(c.error);
        setCourse(c);
        const list = Array.isArray(l) ? l : [];
        setLessons(list);
        if (list.length) setActiveLesson(list[0]);
      })
      .catch((e) => setError(e.message || 'فشل التحميل'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <LoadingSpinner />;
  if (error || !course) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-red-600 mb-4">{error || 'الكورس غير موجود'}</p>
        <Link to="/courses" className="text-amber-700 font-medium">العودة للكورسات</Link>
      </div>
    );
  }

  const lvl = levelLabels[course.level] || levelLabels.beginner;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <Link to="/courses" className="inline-flex items-center gap-1 text-sm text-stone-500 hover:text-amber-700 mb-6">
        <ArrowRight className="w-4 h-4" />
        العودة للكورسات
      </Link>

      <div className="bg-gradient-to-l from-amber-700 to-stone-800 rounded-3xl p-6 md:p-10 text-white mb-8 shadow-xl shadow-stone-400/40">
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span className={`px-3 py-1 rounded-lg text-xs font-bold ${lvl.color}`}>{lvl.ar}</span>
          {course.duration && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-white/15 text-xs">
              <Clock className="w-3.5 h-3.5" />
              {course.duration}
            </span>
          )}
        </div>
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{course.title_ar || course.title}</h1>
        <p className="text-amber-100 text-lg mb-3">{course.title}</p>
        <p className="text-amber-100/90 max-w-3xl leading-relaxed">{course.description_ar || course.description}</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-2">
          <h2 className="font-bold text-stone-900 mb-3 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-700" />
            الدروس ({lessons.length})
          </h2>
          {lessons.length === 0 ? (
            <p className="text-stone-500 text-sm py-6">لا توجد دروس بعد</p>
          ) : (
            lessons.map((lesson, idx) => (
              <button
                key={lesson.id}
                onClick={() => setActiveLesson(lesson)}
                className={`w-full text-right p-3 rounded-xl border transition-all ${
                  activeLesson?.id === lesson.id
                    ? 'border-amber-400 bg-amber-50 shadow-sm'
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 ${
                    activeLesson?.id === lesson.id ? 'bg-amber-700 text-white' : 'bg-stone-200 text-stone-600'
                  }`}>
                    {idx + 1}
                  </span>
                  <div className="min-w-0">
                    <div className="font-semibold text-stone-900 text-sm truncate">{lesson.title_ar || lesson.title}</div>
                    <div className="text-xs text-stone-500 mt-0.5">{lesson.duration_minutes || 30} دقيقة</div>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>

        <div className="lg:col-span-2">
          {activeLesson ? (
            <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 md:p-8">
              <div className="flex items-center gap-2 text-amber-700 text-sm font-medium mb-3">
                <PlayCircle className="w-4 h-4" />
                محتوى الدرس
              </div>
              <h2 className="text-2xl font-bold text-stone-900 mb-1">{activeLesson.title_ar || activeLesson.title}</h2>
              <p className="text-amber-700 mb-6">{activeLesson.title}</p>
              <div className="prose prose-stone max-w-none text-stone-700 leading-relaxed whitespace-pre-wrap">
                {activeLesson.content || 'لا يوجد محتوى لهذا الدرس بعد.'}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center text-stone-500">
              اختر درساً لعرض محتواه
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
