import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, BookOpen, Home, ClipboardList, Trophy, LogOut, User, Shield, GraduationCap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import supabase from '../lib/supabase';

const navItems = [
  { to: '/', label: 'الرئيسية', icon: Home },
  { to: '/courses', label: 'الكورسات', icon: BookOpen },
  { to: '/quizzes', label: 'الاختبارات', icon: ClipboardList },
  { to: '/leaderboard', label: 'لوحة المتفوقين', icon: Trophy },
];

export default function Layout({ children }) {
  const [open, setOpen] = useState(false);
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-stone-100" dir="rtl">
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-stone-300 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-700 to-stone-800 flex items-center justify-center shadow-lg shadow-stone-400/40 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-stone-900 text-lg leading-tight">English Mastery</div>
                <div className="text-[11px] text-amber-700 font-medium">Mr. Sherif Atta</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              {navItems.map(({ to, label, icon: Icon }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  className={({ isActive }) =>
                    `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-amber-50 text-amber-800'
                        : 'text-stone-600 hover:bg-stone-200 hover:text-stone-900'
                    }`
                  }
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </NavLink>
              ))}
            </nav>

            <div className="hidden md:flex items-center gap-2">
              {user ? (
                <>
                  {profile?.role === 'admin' && (
                    <Link
                      to="/admin"
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors"
                    >
                      <Shield className="w-4 h-4" />
                      لوحة المشرف
                    </Link>
                  )}
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-200">
                    <User className="w-4 h-4 text-stone-500" />
                    <span className="text-sm text-stone-700 max-w-[120px] truncate">{profile?.full_name || user.email}</span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="p-2 rounded-lg text-stone-500 hover:bg-red-50 hover:text-red-600 transition-colors"
                    title="تسجيل الخروج"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="px-4 py-2 rounded-lg bg-amber-700 text-white text-sm font-medium hover:bg-amber-800 transition-colors shadow-sm shadow-stone-400/40"
                >
                  تسجيل الدخول
                </Link>
              )}
            </div>

            <button
              className="md:hidden p-2 rounded-lg text-stone-600 hover:bg-stone-200"
              onClick={() => setOpen(!open)}
            >
              {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {open && (
          <div className="md:hidden border-t border-stone-200 bg-white px-4 py-3 space-y-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium ${
                    isActive ? 'bg-amber-50 text-amber-800' : 'text-stone-600'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                {label}
              </NavLink>
            ))}
            {user ? (
              <>
                {profile?.role === 'admin' && (
                  <Link to="/admin" onClick={() => setOpen(false)} className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-amber-700 bg-amber-50">
                    <Shield className="w-4 h-4" />
                    لوحة المشرف
                  </Link>
                )}
                <button onClick={() => { handleLogout(); setOpen(false); }} className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-red-600 w-full">
                  <LogOut className="w-4 h-4" />
                  تسجيل الخروج
                </button>
              </>
            ) : (
              <Link to="/login" onClick={() => setOpen(false)} className="flex items-center justify-center px-3 py-2.5 rounded-lg text-sm font-medium bg-amber-700 text-white">
                تسجيل الدخول
              </Link>
            )}
          </div>
        )}
      </header>

      <main>{children}</main>

      <footer className="bg-zinc-900 text-stone-300 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-600 to-stone-700 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-white">English Mastery</div>
                <div className="text-sm text-stone-400">مع المدرس Mr. Sherif Atta</div>
              </div>
            </div>
            <p className="text-sm text-stone-400 text-center">
              منصة تعليمية متخصصة في اللغة الإنجليزية · جميع الحقوق محفوظة © {new Date().getFullYear()}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
