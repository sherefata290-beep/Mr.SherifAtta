export default function LoadingSpinner({ text = 'جاري التحميل...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="w-12 h-12 border-4 border-amber-700 border-t-transparent rounded-full animate-spin" />
      <p className="text-stone-600 font-medium">{text}</p>
    </div>
  );
}
