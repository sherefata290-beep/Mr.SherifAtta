import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Filter, Search } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';

const levelLabels = {
  beginner: { ar: 'مبتدئ', color: 'bg-yellow-100 text-yellow-900' },
  intermediate: { ar: 'متوسط', color: 'bg-stone-200 text-stone-800' },
  advanced: { ar: 'متقدم', color: 'bg-stone-200 text-stone-800' },
};

export default function Courses() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/courses')
      .then((r) => r.json())
      .then((data) => setCourses(Array.isArray(data) ? data : []))
      .catch(() => setError('فشل تحميل الكورسات'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = courses.filter((c) => {
    const matchLevel = filter === 'all' || c.level === filter;
    const q = search.trim().toLowerCase();
    const matchSearch =
      !q ||
      c.title?.toLowerCase().includes(q) ||
      c.title_ar?.includes(search) ||
      c.description?.toLowerCase().includes(q);
    return matchLevel && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-stone-900 mb-2">الكورسات</h1>
        <p className="text-stone-600">اختر الكورس المناسب لمستواك وابدأ التعلم مع Mr. Sherif Atta</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-8">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            placeholder="ابحث عن كورس..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-stone-300 bg-white focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
          />
        </div>
        <div className="flex items-center gap-2 overflow-x-auto">
          <Filter className="w-4 h-4 text-stone-400 shrink-0" />
          {['all', 'beginner', 'intermediate', 'advanced'].map((lv) => (
            <button
              key={lv}
              onClick={() => setFilter(lv)}
              className={`px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                filter === lv
                  ? 'bg-amber-700 text-white'
                  : 'bg-white border border-stone-300 text-stone-600 hover:bg-stone-100'
              }`}
            >
              {lv === 'all' ? 'الكل' : levelLabels[lv]?.ar || lv}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : error ? (
        <div className="text-center py-16 text-red-600">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-stone-500">لا توجد كورسات مطابقة</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((course) => {
            const lvl = levelLabels[course.level] || levelLabels.beginner;
            return (
              <Link
                key={course.id}
                to={`/courses/${course.id}`}
                className="group bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all"
              >
                <div className="h-40 bg-gradient-to-br from-amber-600 via-yellow-700 to-stone-800 flex items-center justify-center relative">
                  <BookOpen className="w-16 h-16 text-white/70" />
                  <span className={`absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold ${lvl.color}`}>
                    {lvl.ar}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-stone-900 text-lg mb-0.5 group-hover:text-amber-700 transition-colors">
                    {course.title_ar || course.title}
                  </h3>
                  <p className="text-sm text-amber-700/80 mb-2 font-medium">{course.title}</p>
                  <p className="text-stone-600 text-sm line-clamp-3 mb-4">
                    {course.description_ar || course.description}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{course.duration || 'غير محدد'}</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
