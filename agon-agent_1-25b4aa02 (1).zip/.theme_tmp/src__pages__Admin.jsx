import { useEffect, useState } from 'react';
import {
  LayoutDashboard, BookOpen, ClipboardList, Users, HelpCircle,
  Plus, Pencil, Trash2, X, Save, BarChart3
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';

const TABS = [
  { id: 'dashboard', label: 'نظرة عامة', icon: LayoutDashboard },
  { id: 'courses', label: 'الكورسات', icon: BookOpen },
  { id: 'lessons', label: 'الدروس', icon: BookOpen },
  { id: 'quizzes', label: 'الاختبارات', icon: ClipboardList },
  { id: 'questions', label: 'الأسئلة', icon: HelpCircle },
  { id: 'students', label: 'الطلاب', icon: Users },
  { id: 'results', label: 'النتائج', icon: BarChart3 },
];

const emptyCourse = { title: '', title_ar: '', description: '', description_ar: '', level: 'beginner', duration: '', is_published: true };
const emptyLesson = { course_id: '', title: '', title_ar: '', content: '', order_index: 1, duration_minutes: 30 };
const emptyQuiz = { title: '', title_ar: '', description: '', course_id: '', level: 'beginner', duration_minutes: 20, is_published: true };
const emptyQuestion = { quiz_id: '', question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_answer: 'a', points: 1, order_index: 1 };

export default function Admin() {
  const [tab, setTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [courses, setCourses] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [modal, setModal] = useState(null); // { type, mode, data }
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [filterCourse, setFilterCourse] = useState('');
  const [filterQuiz, setFilterQuiz] = useState('');

  const loadAll = async () => {
    setLoading(true);
    setError('');
    try {
      const [s, c, l, q, qs, st, r] = await Promise.all([
        fetch('/api/stats').then((x) => x.json()),
        fetch('/api/courses?admin=true').then((x) => x.json()),
        fetch('/api/lessons').then((x) => x.json()),
        fetch('/api/quizzes?admin=true').then((x) => x.json()),
        fetch('/api/questions').then((x) => x.json()),
        fetch('/api/profiles').then((x) => x.json()),
        fetch('/api/results').then((x) => x.json()),
      ]);
      setStats(s);
      setCourses(Array.isArray(c) ? c : []);
      setLessons(Array.isArray(l) ? l : []);
      setQuizzes(Array.isArray(q) ? q : []);
      setQuestions(Array.isArray(qs) ? qs : []);
      setStudents(Array.isArray(st) ? st : []);
      setResults(Array.isArray(r) ? r : []);
    } catch {
      setError('فشل تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  const openCreate = (type) => {
    const defaults = {
      course: emptyCourse,
      lesson: { ...emptyLesson, course_id: courses[0]?.id || '' },
      quiz: emptyQuiz,
      question: { ...emptyQuestion, quiz_id: quizzes[0]?.id || '' },
    };
    setForm(defaults[type] || {});
    setModal({ type, mode: 'create' });
  };

  const openEdit = (type, data) => {
    setForm({ ...data });
    setModal({ type, mode: 'edit', data });
  };

  const closeModal = () => {
    setModal(null);
    setForm({});
  };

  const endpoints = {
    course: '/api/courses',
    lesson: '/api/lessons',
    quiz: '/api/quizzes',
    question: '/api/questions',
  };

  const handleSave = async () => {
    if (!modal) return;
    setSaving(true);
    setError('');
    try {
      const endpoint = endpoints[modal.type];
      const body = { ...form };
      if (body.course_id === '') body.course_id = null;
      if (body.course_id) body.course_id = Number(body.course_id);
      if (body.quiz_id) body.quiz_id = Number(body.quiz_id);
      if (body.order_index) body.order_index = Number(body.order_index);
      if (body.duration_minutes) body.duration_minutes = Number(body.duration_minutes);
      if (body.points) body.points = Number(body.points);

      const method = modal.mode === 'create' ? 'POST' : 'PUT';
      if (modal.mode === 'edit') body.id = modal.data.id;

      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل الحفظ');
      closeModal();
      await loadAll();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (type, id) => {
    if (!confirm('هل أنت متأكد من الحذف؟')) return;
    try {
      const endpoint = type === 'result' ? '/api/results' : type === 'student' ? '/api/profiles' : endpoints[type];
      const res = await fetch(endpoint, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'فشل الحذف');
      }
      await loadAll();
    } catch (e) {
      setError(e.message);
    }
  };

  const updateStudentRole = async (id, role) => {
    try {
      await fetch('/api/profiles', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, role }),
      });
      await loadAll();
    } catch (e) {
      setError(e.message);
    }
  };

  const filteredLessons = filterCourse
    ? lessons.filter((l) => String(l.course_id) === String(filterCourse))
    : lessons;
  const filteredQuestions = filterQuiz
    ? questions.filter((q) => String(q.quiz_id) === String(filterQuiz))
    : questions;

  const field = (key, label, type = 'text', opts = null) => (
    <div key={key}>
      <label className="block text-sm font-medium text-stone-700 mb-1">{label}</label>
      {type === 'textarea' ? (
        <textarea
          value={form[key] ?? ''}
          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          rows={4}
          className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
        />
      ) : type === 'select' ? (
        <select
          value={form[key] ?? ''}
          onChange={(e) => setForm({ ...form, [key]: e.target.value === 'true' ? true : e.target.value === 'false' ? false : e.target.value })}
          className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
        >
          {opts?.map((o) => (
            <option key={String(o.value)} value={o.value}>{o.label}</option>
          ))}
        </select>
      ) : type === 'checkbox' ? (
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={!!form[key]}
            onChange={(e) => setForm({ ...form, [key]: e.target.checked })}
            className="rounded border-stone-400 text-amber-700 focus:ring-amber-600"
          />
          {label}
        </label>
      ) : (
        <input
          type={type}
          value={form[key] ?? ''}
          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
          dir={type === 'number' || key.includes('title') && !key.includes('_ar') ? 'ltr' : undefined}
        />
      )}
    </div>
  );

  const renderModalFields = () => {
    if (!modal) return null;
    if (modal.type === 'course') {
      return (
        <div className="space-y-3">
          {field('title', 'العنوان (English)')}
          {field('title_ar', 'العنوان (عربي)')}
          {field('description', 'الوصف (English)', 'textarea')}
          {field('description_ar', 'الوصف (عربي)', 'textarea')}
          {field('level', 'المستوى', 'select', [
            { value: 'beginner', label: 'مبتدئ' },
            { value: 'intermediate', label: 'متوسط' },
            { value: 'advanced', label: 'متقدم' },
          ])}
          {field('duration', 'المدة')}
          {field('is_published', 'منشور', 'select', [
            { value: true, label: 'نعم' },
            { value: false, label: 'لا' },
          ])}
        </div>
      );
    }
    if (modal.type === 'lesson') {
      return (
        <div className="space-y-3">
          {field('course_id', 'الكورس', 'select', courses.map((c) => ({ value: c.id, label: c.title_ar || c.title })))}
          {field('title', 'العنوان (English)')}
          {field('title_ar', 'العنوان (عربي)')}
          {field('content', 'المحتوى', 'textarea')}
          {field('order_index', 'الترتيب', 'number')}
          {field('duration_minutes', 'المدة بالدقائق', 'number')}
        </div>
      );
    }
    if (modal.type === 'quiz') {
      return (
        <div className="space-y-3">
          {field('title', 'العنوان (English)')}
          {field('title_ar', 'العنوان (عربي)')}
          {field('description', 'الوصف', 'textarea')}
          {field('course_id', 'الكورس (اختياري)', 'select', [
            { value: '', label: '— بدون —' },
            ...courses.map((c) => ({ value: c.id, label: c.title_ar || c.title })),
          ])}
          {field('level', 'المستوى', 'select', [
            { value: 'beginner', label: 'مبتدئ' },
            { value: 'intermediate', label: 'متوسط' },
            { value: 'advanced', label: 'متقدم' },
          ])}
          {field('duration_minutes', 'المدة بالدقائق', 'number')}
          {field('is_published', 'منشور', 'select', [
            { value: true, label: 'نعم' },
            { value: false, label: 'لا' },
          ])}
        </div>
      );
    }
    if (modal.type === 'question') {
      return (
        <div className="space-y-3">
          {field('quiz_id', 'الاختبار', 'select', quizzes.map((q) => ({ value: q.id, label: q.title_ar || q.title })))}
          {field('question_text', 'نص السؤال', 'textarea')}
          {field('option_a', 'الخيار A')}
          {field('option_b', 'الخيار B')}
          {field('option_c', 'الخيار C')}
          {field('option_d', 'الخيار D')}
          {field('correct_answer', 'الإجابة الصحيحة', 'select', [
            { value: 'a', label: 'A' },
            { value: 'b', label: 'B' },
            { value: 'c', label: 'C' },
            { value: 'd', label: 'D' },
          ])}
          {field('points', 'النقاط', 'number')}
          {field('order_index', 'الترتيب', 'number')}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-stone-900 mb-1">لوحة تحكم المشرف</h1>
        <p className="text-stone-600">إدارة كاملة لمنصة English Mastery</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
              tab === t.id
                ? 'bg-amber-700 text-white shadow-sm'
                : 'bg-white border border-stone-300 text-stone-600 hover:bg-stone-100'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError('')}><X className="w-4 h-4" /></button>
        </div>
      )}

      {loading ? (
        <LoadingSpinner />
      ) : (
        <>
          {tab === 'dashboard' && stats && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { label: 'الكورسات', value: stats.courses, color: 'from-amber-600 to-yellow-700' },
                { label: 'الدروس', value: stats.lessons, color: 'from-stone-600 to-zinc-700' },
                { label: 'الاختبارات', value: stats.quizzes, color: 'from-amber-700 to-yellow-800' },
                { label: 'الأسئلة', value: stats.questions, color: 'from-amber-500 to-orange-500' },
                { label: 'الطلاب', value: stats.students, color: 'from-emerald-500 to-teal-500' },
                { label: 'النتائج', value: stats.results, color: 'from-stone-500 to-zinc-600' },
              ].map((s) => (
                <div key={s.label} className="bg-white rounded-2xl border border-stone-200 p-5 shadow-sm">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.color} mb-3`} />
                  <div className="text-3xl font-black text-stone-900">{s.value}</div>
                  <div className="text-sm text-stone-500">{s.label}</div>
                </div>
              ))}
            </div>
          )}

          {tab === 'courses' && (
            <Section
              title="الكورسات"
              onAdd={() => openCreate('course')}
              addLabel="كورس جديد"
            >
              <Table
                headers={['#', 'العنوان', 'المستوى', 'المدة', 'الحالة', 'إجراءات']}
                rows={courses.map((c) => [
                  c.id,
                  <div key="t"><div className="font-medium">{c.title_ar || c.title}</div><div className="text-xs text-stone-400">{c.title}</div></div>,
                  c.level,
                  c.duration || '—',
                  c.is_published ? <Badge green>منشور</Badge> : <Badge>مسودة</Badge>,
                  <Actions key="a" onEdit={() => openEdit('course', c)} onDelete={() => handleDelete('course', c.id)} />,
                ])}
              />
            </Section>
          )}

          {tab === 'lessons' && (
            <Section
              title="الدروس"
              onAdd={() => openCreate('lesson')}
              addLabel="درس جديد"
              filter={
                <select
                  value={filterCourse}
                  onChange={(e) => setFilterCourse(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-stone-300 text-sm"
                >
                  <option value="">كل الكورسات</option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>{c.title_ar || c.title}</option>
                  ))}
                </select>
              }
            >
              <Table
                headers={['#', 'العنوان', 'الكورس', 'الترتيب', 'المدة', 'إجراءات']}
                rows={filteredLessons.map((l) => [
                  l.id,
                  l.title_ar || l.title,
                  courses.find((c) => c.id === l.course_id)?.title_ar || l.course_id,
                  l.order_index,
                  `${l.duration_minutes || 30} د`,
                  <Actions key="a" onEdit={() => openEdit('lesson', l)} onDelete={() => handleDelete('lesson', l.id)} />,
                ])}
              />
            </Section>
          )}

          {tab === 'quizzes' && (
            <Section title="الاختبارات" onAdd={() => openCreate('quiz')} addLabel="اختبار جديد">
              <Table
                headers={['#', 'العنوان', 'المستوى', 'المدة', 'الحالة', 'إجراءات']}
                rows={quizzes.map((q) => [
                  q.id,
                  <div key="t"><div className="font-medium">{q.title_ar || q.title}</div><div className="text-xs text-stone-400">{q.title}</div></div>,
                  q.level,
                  `${q.duration_minutes || 20} د`,
                  q.is_published ? <Badge green>منشور</Badge> : <Badge>مسودة</Badge>,
                  <Actions key="a" onEdit={() => openEdit('quiz', q)} onDelete={() => handleDelete('quiz', q.id)} />,
                ])}
              />
            </Section>
          )}

          {tab === 'questions' && (
            <Section
              title="الأسئلة"
              onAdd={() => openCreate('question')}
              addLabel="سؤال جديد"
              filter={
                <select
                  value={filterQuiz}
                  onChange={(e) => setFilterQuiz(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-stone-300 text-sm"
                >
                  <option value="">كل الاختبارات</option>
                  {quizzes.map((q) => (
                    <option key={q.id} value={q.id}>{q.title_ar || q.title}</option>
                  ))}
                </select>
              }
            >
              <Table
                headers={['#', 'السؤال', 'الاختبار', 'الصحيحة', 'نقاط', 'إجراءات']}
                rows={filteredQuestions.map((q) => [
                  q.id,
                  <span key="q" className="line-clamp-2 max-w-xs text-sm">{q.question_text}</span>,
                  quizzes.find((x) => x.id === q.quiz_id)?.title_ar || q.quiz_id,
                  String(q.correct_answer).toUpperCase(),
                  q.points,
                  <Actions key="a" onEdit={() => openEdit('question', q)} onDelete={() => handleDelete('question', q.id)} />,
                ])}
              />
            </Section>
          )}

          {tab === 'students' && (
            <Section title="الطلاب والمستخدمون">
              <Table
                headers={['الاسم', 'البريد', 'الدور', 'النقاط', 'إجراءات']}
                rows={students.map((s) => [
                  s.full_name,
                  <span key="e" dir="ltr" className="text-sm">{s.email}</span>,
                  <select
                    key="r"
                    value={s.role}
                    onChange={(e) => updateStudentRole(s.id, e.target.value)}
                    className="px-2 py-1 rounded-lg border border-stone-300 text-xs"
                  >
                    <option value="student">طالب</option>
                    <option value="admin">مشرف</option>
                  </select>,
                  s.total_points || 0,
                  <button
                    key="d"
                    onClick={() => handleDelete('student', s.id)}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>,
                ])}
              />
            </Section>
          )}

          {tab === 'results' && (
            <Section title="نتائج الاختبارات">
              <Table
                headers={['#', 'الطالب', 'الاختبار', 'النتيجة', 'النسبة', 'التاريخ', 'حذف']}
                rows={results.map((r) => [
                  r.id,
                  r.user_name,
                  quizzes.find((q) => q.id === r.quiz_id)?.title_ar || `#${r.quiz_id}`,
                  `${r.score}/${r.total_questions}`,
                  `${r.percentage}%`,
                  r.completed_at ? new Date(r.completed_at).toLocaleDateString('ar-EG') : '—',
                  <button
                    key="d"
                    onClick={() => handleDelete('result', r.id)}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>,
                ])}
              />
            </Section>
          )}
        </>
      )}

      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-stone-200 sticky top-0 bg-white">
              <h3 className="font-bold text-lg text-stone-900">
                {modal.mode === 'create' ? 'إضافة' : 'تعديل'}{' '}
                {{ course: 'كورس', lesson: 'درس', quiz: 'اختبار', question: 'سؤال' }[modal.type]}
              </h3>
              <button onClick={closeModal} className="p-1.5 rounded-lg hover:bg-stone-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5">{renderModalFields()}</div>
            <div className="flex gap-2 p-5 border-t border-stone-200 sticky bottom-0 bg-white">
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-amber-700 text-white font-semibold hover:bg-amber-800 disabled:opacity-60"
              >
                <Save className="w-4 h-4" />
                {saving ? 'جاري الحفظ...' : 'حفظ'}
              </button>
              <button onClick={closeModal} className="px-5 py-2.5 rounded-xl border border-stone-300 text-stone-600 font-medium hover:bg-stone-100">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ title, onAdd, addLabel, filter, children }) {
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h2 className="text-xl font-bold text-stone-900">{title}</h2>
        <div className="flex items-center gap-2">
          {filter}
          {onAdd && (
            <button
              onClick={onAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-700 text-white text-sm font-semibold hover:bg-amber-800"
            >
              <Plus className="w-4 h-4" />
              {addLabel}
            </button>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

function Table({ headers, rows }) {
  if (!rows.length) {
    return <div className="text-center py-12 text-stone-500 bg-white rounded-2xl border border-stone-200">لا توجد بيانات</div>;
  }
  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-stone-200 bg-stone-100/80">
            {headers.map((h) => (
              <th key={h} className="text-right px-4 py-3 font-semibold text-stone-600 whitespace-nowrap">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className="border-b border-stone-100 hover:bg-stone-100/50">
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-3 text-stone-700 whitespace-nowrap">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Actions({ onEdit, onDelete }) {
  return (
    <div className="flex items-center gap-1">
      <button onClick={onEdit} className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-50">
        <Pencil className="w-4 h-4" />
      </button>
      <button onClick={onDelete} className="p-1.5 rounded-lg text-red-500 hover:bg-red-50">
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
}

function Badge({ children, green }) {
  return (
    <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
      green ? 'bg-yellow-100 text-yellow-900' : 'bg-stone-200 text-stone-600'
    }`}>
      {children}
    </span>
  );
}
