import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BookOpen, ClipboardList, Trophy, Star, ArrowLeft, Users,
  Award, Target, Sparkles, CheckCircle2
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';

const features = [
  {
    icon: BookOpen,
    title: 'كورسات متكاملة',
    desc: 'مناهج منظمة من المبتدئ حتى المتقدم مع دروس واضحة وتدريبات عملية.',
    color: 'from-amber-600 to-yellow-700',
  },
  {
    icon: ClipboardList,
    title: 'اختبارات تفاعلية',
    desc: 'قيّم مستواك باختبارات متعددة المستويات واحصل على نتائج فورية.',
    color: 'from-stone-600 to-zinc-700',
  },
  {
    icon: Trophy,
    title: 'لوحة المتفوقين',
    desc: 'نافس زملاءك وتصدّر قائمة المتفوقين بنقاطك ونتائجك المميزة.',
    color: 'from-amber-500 to-orange-500',
  },
  {
    icon: Target,
    title: 'متابعة التقدم',
    desc: 'تابع أداءك ونقاطك وتطورك في اللغة الإنجليزية خطوة بخطوة.',
    color: 'from-emerald-500 to-teal-500',
  },
];

const levels = [
  { name: 'Beginner', nameAr: 'مبتدئ', color: 'bg-yellow-100 text-yellow-900' },
  { name: 'Intermediate', nameAr: 'متوسط', color: 'bg-stone-200 text-stone-800' },
  { name: 'Advanced', nameAr: 'متقدم', color: 'bg-stone-200 text-stone-800' },
];

export default function Home() {
  const [courses, setCourses] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/courses').then((r) => r.json()),
      fetch('/api/stats').then((r) => r.json()),
    ])
      .then(([c, s]) => {
        setCourses(Array.isArray(c) ? c.slice(0, 3) : []);
        setStats(s);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-zinc-950 via-stone-900 to-zinc-900 text-white">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 right-10 w-72 h-72 bg-amber-500 rounded-full blur-[100px]" />
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-stone-700 rounded-full blur-[120px]" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 md:py-28">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-sm mb-6">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>منصة تعليمية متخصصة في الإنجليزية</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-4">
                English Mastery
              </h1>
              <p className="text-xl md:text-2xl text-amber-200 font-medium mb-3">
                مع المدرس Mr. Sherif Atta
              </p>
              <p className="text-stone-300 text-lg leading-relaxed mb-8 max-w-lg">
                اتقن اللغة الإنجليزية بخطوات واضحة: كورسات منظمة، اختبارات تفاعلية، ومتابعة مستمرة لتقدمك.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/courses"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-amber-800 font-bold hover:bg-amber-50 transition-colors shadow-lg shadow-black/20"
                >
                  استكشف الكورسات
                  <ArrowLeft className="w-4 h-4" />
                </Link>
                <Link
                  to="/quizzes"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white/10 border border-white/25 text-white font-semibold hover:bg-white/20 transition-colors"
                >
                  ابدأ اختباراً
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="hidden md:block"
            >
              <div className="relative bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8 shadow-2xl">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-2xl font-black text-white shadow-lg">
                    SA
                  </div>
                  <div>
                    <div className="text-xl font-bold">Mr. Sherif Atta</div>
                    <div className="text-amber-200 text-sm">مدرس اللغة الإنجليزية</div>
                  </div>
                </div>
                <ul className="space-y-3">
                  {['شرح مبسط ومنظم', 'تدريبات واختبارات عملية', 'متابعة مستوى الطلاب', 'منهج من المبتدئ للمتقدم'].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-stone-200">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
                {stats && (
                  <div className="grid grid-cols-3 gap-3 mt-8 pt-6 border-t border-white/15">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{stats.courses}</div>
                      <div className="text-xs text-amber-200">كورسات</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{stats.quizzes}</div>
                      <div className="text-xs text-amber-200">اختبارات</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{stats.students}</div>
                      <div className="text-xs text-amber-200">طلاب</div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-stone-900 mb-3">لماذا English Mastery؟</h2>
          <p className="text-stone-600 max-w-2xl mx-auto">تجربة تعليمية متكاملة تجمع بين الشرح المنظم والتقييم المستمر والتحفيز</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-white rounded-2xl p-6 border border-stone-200 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4 shadow-lg`}>
                <f.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-stone-900 text-lg mb-2">{f.title}</h3>
              <p className="text-stone-600 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Levels */}
      <section className="bg-white border-y border-stone-200 py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-stone-900 mb-3">مستويات التعلم</h2>
            <p className="text-stone-600">مسارات واضحة تناسب كل مستوى</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            {levels.map((l) => (
              <div key={l.name} className={`px-8 py-4 rounded-2xl font-bold text-lg ${l.color} border border-current/10`}>
                <span className="block text-center">{l.nameAr}</span>
                <span className="block text-center text-sm font-medium opacity-80">{l.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-stone-900 mb-1">أحدث الكورسات</h2>
            <p className="text-stone-600">ابدأ رحلتك مع أفضل الكورسات</p>
          </div>
          <Link to="/courses" className="text-amber-700 font-semibold hover:text-amber-800 flex items-center gap-1">
            عرض الكل
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <LoadingSpinner />
        ) : courses.length === 0 ? (
          <div className="text-center py-12 text-stone-500">لا توجد كورسات حالياً</div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Link
                key={course.id}
                to={`/courses/${course.id}`}
                className="group bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all"
              >
                <div className="h-36 bg-gradient-to-br from-amber-600 via-yellow-700 to-stone-800 flex items-center justify-center relative">
                  <BookOpen className="w-14 h-14 text-white/80" />
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-white/90 text-xs font-bold text-amber-800 capitalize">
                    {course.level}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-stone-900 text-lg mb-1 group-hover:text-amber-700 transition-colors">
                    {course.title_ar || course.title}
                  </h3>
                  <p className="text-sm text-stone-500 mb-2">{course.title}</p>
                  <p className="text-stone-600 text-sm line-clamp-2 mb-3">{course.description_ar || course.description}</p>
                  <div className="flex items-center justify-between text-xs text-stone-500">
                    <span>{course.duration || '—'}</span>
                    <span className="text-amber-700 font-semibold">عرض التفاصيل ←</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="rounded-3xl bg-gradient-to-l from-amber-700 to-stone-800 p-8 md:p-12 text-white text-center shadow-xl shadow-stone-400/40">
          <Award className="w-12 h-12 mx-auto mb-4 text-amber-300" />
          <h2 className="text-2xl md:text-3xl font-bold mb-3">هل أنت مستعد للتميز؟</h2>
          <p className="text-amber-100 mb-6 max-w-xl mx-auto">انضم لطلاب English Mastery وابدأ رحلتك مع Mr. Sherif Atta اليوم</p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/login" className="px-6 py-3 rounded-xl bg-white text-amber-800 font-bold hover:bg-amber-50 transition-colors">
              إنشاء حساب
            </Link>
            <Link to="/leaderboard" className="px-6 py-3 rounded-xl bg-white/15 border border-white/30 font-semibold hover:bg-white/25 transition-colors flex items-center gap-2">
              <Star className="w-4 h-4" />
              لوحة المتفوقين
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
