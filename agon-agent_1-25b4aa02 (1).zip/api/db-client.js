import { createClient } from '@supabase/supabase-js';
import { triggerRestore, pingDatabase } from './db-wake.js';

function cleanEnv(value) {
  if (value == null) return '';
  let v = String(value).trim();
  if (
    (v.startsWith('"') && v.endsWith('"')) ||
    (v.startsWith("'") && v.endsWith("'"))
  ) {
    v = v.slice(1, -1).trim();
  }
  return v;
}

const supabaseUrl = cleanEnv(
  process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VITE_SUPABASE_URL
);
const serviceKey = cleanEnv(process.env.SUPABASE_SERVICE_ROLE_KEY);
const anonKey = cleanEnv(
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY
);

// Prefer service role on the server; fall back to anon so public reads still work
let activeKey = serviceKey || anonKey;
let usingAnonFallback = !serviceKey && Boolean(anonKey);

if (!supabaseUrl || !activeKey) {
  console.error(
    '[db-client] Missing Supabase env. URL:',
    !!supabaseUrl,
    'KEY:',
    !!activeKey
  );
}

let wakeStarted = false;
function ensureAwake() {
  if (wakeStarted) return;
  wakeStarted = true;
  try {
    triggerRestore();
    pingDatabase(supabaseUrl, activeKey);
  } catch {
    /* ignore */
  }
  setTimeout(() => {
    wakeStarted = false;
  }, 30_000);
}

function makeClient(key) {
  return createClient(supabaseUrl || 'https://invalid.supabase.co', key || 'invalid', {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    global: {
      fetch: async (url, options) => {
        ensureAwake();
        let res;
        try {
          res = await fetch(url, options);
        } catch (err) {
          triggerRestore();
          await new Promise((r) => setTimeout(r, 800));
          try {
            res = await fetch(url, options);
          } catch (err2) {
            throw err2;
          }
        }

        // If service role key is rejected, transparently fall back to anon key once
        if (
          res &&
          res.status === 401 &&
          serviceKey &&
          anonKey &&
          serviceKey !== anonKey &&
          activeKey === serviceKey
        ) {
          try {
            const bodyText = await res.clone().text();
            if (
              /invalid api key|unregistered api key|jwt/i.test(bodyText) ||
              bodyText.includes('Invalid API key')
            ) {
              console.warn(
                '[db-client] Service role key rejected — falling back to anon key'
              );
              activeKey = anonKey;
              usingAnonFallback = true;
              // retry original request with anon key by swapping apikey/Authorization headers
              const headers = new Headers(options?.headers || {});
              headers.set('apikey', anonKey);
              const auth = headers.get('Authorization') || headers.get('authorization');
              // Only replace bearer if it was the service key
              if (auth && auth.includes(serviceKey)) {
                headers.set('Authorization', `Bearer ${anonKey}`);
              } else if (!auth) {
                headers.set('Authorization', `Bearer ${anonKey}`);
              }
              const retry = await fetch(url, { ...options, headers });
              return retry;
            }
          } catch {
            /* keep original res */
          }
        }

        if (res && !res.ok && res.status >= 500) {
          triggerRestore();
          await new Promise((r) => setTimeout(r, 1200));
          try {
            const retry = await fetch(url, options);
            return retry;
          } catch {
            return res;
          }
        }
        return res;
      },
    },
  });
}

const supabase = makeClient(activeKey);

export function getSupabaseConfigStatus() {
  return {
    hasUrl: Boolean(supabaseUrl),
    hasServiceKey: Boolean(serviceKey),
    hasAnonKey: Boolean(anonKey),
    usingAnonFallback,
    urlHost: supabaseUrl
      ? (() => {
          try {
            return new URL(supabaseUrl).host;
          } catch {
            return 'invalid-url';
          }
        })()
      : null,
  };
}

export default supabase;
