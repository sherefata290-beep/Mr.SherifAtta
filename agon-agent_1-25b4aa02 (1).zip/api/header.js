/**
 * Public site header / hero configuration.
 * Stored in settings key: site_header
 * Also keeps homepage_image in sync with featured_image for backward compatibility.
 */
import supabase from './db-client.js';
import {
  handleOptions,
  rateLimit,
  rejectRateLimit,
  requireAdmin,
  sanitizeText,
  sanitizeUrl,
  methodNotAllowed,
  serverError,
} from './security.js';

const HEADER_KEY = 'site_header';
const HOMEPAGE_IMAGE_KEY = 'homepage_image';

export const DEFAULT_HEADER = {
  enabled: true,
  badge: 'منصة تعليمية متخصصة في الإنجليزية',
  title: 'English Mastery',
  subtitle: 'مع المدرس Mr. Sherif Atta',
  description:
    'اتقن اللغة الإنجليزية بخطوات واضحة: كورسات منظمة، اختبارات تفاعلية، ومتابعة مستمرة لتقدمك.',
  primary_cta: { label: 'استكشف الكورسات', to: '/courses', style: 'primary' },
  secondary_cta: { label: 'ابدأ اختباراً', to: '/quizzes', style: 'secondary' },
  /** Extra / full list of CTAs (admin can add unlimited buttons) */
  ctas: [
    { id: 'cta-primary', label: 'استكشف الكورسات', to: '/courses', style: 'primary', enabled: true },
    { id: 'cta-secondary', label: 'ابدأ اختباراً', to: '/quizzes', style: 'secondary', enabled: true },
  ],
  side_enabled: true,
  side_name: 'Mr. Sherif Atta',
  side_role: 'مدرس اللغة الإنجليزية',
  side_initials: 'SA',
  side_points: [
    'شرح مبسط ومنظم',
    'تدريبات واختبارات عملية',
    'متابعة مستوى الطلاب',
    'منهج من المبتدئ للمتقدم',
  ],
  show_stats: true,
  background_image: '',
  /** Optional art-direction images for smaller screens */
  background_image_tablet: '',
  background_image_mobile: '',
  /** object-position hint: center | top | bottom | left | right */
  background_position: 'center',
  featured_image: '',
  slides: [],
  quick_links: [],
};

/**
 * Accept internal paths (/courses) and external URLs.
 * Fixes common mistakes like "/https://youtube.com/..." (leading slash).
 */
function safePathOrUrl(to) {
  let s = String(to || '').trim();
  if (!s) return '/';
  // Block dangerous schemes
  if (/^(javascript|data|vbscript):/i.test(s)) return '/';

  // Fix mistaken "/https://..." or "/http://..." or "/www...."
  s = s.replace(/^\/+(https?:\/\/)/i, '$1');
  s = s.replace(/^\/+(www\.)/i, '$1');
  // Fix "https//" missing colon
  s = s.replace(/^(https?):?\/\//i, (_, p) => `${p.toLowerCase()}://`);

  // Protocol-relative //example.com
  if (s.startsWith('//') && !s.startsWith('///')) {
    s = `https:${s}`;
  }

  // mailto: / tel:
  if (/^(mailto|tel):/i.test(s)) {
    return sanitizeText(s, 300) || '/';
  }

  // External absolute URL
  if (/^https?:\/\//i.test(s)) {
    const cleaned = sanitizeUrl(s, 2000);
    if (cleaned) return cleaned;
    // keep raw https if URL() failed on odd but valid chars
    return s.replace(/[<>"']/g, '').slice(0, 2000);
  }

  // Bare domain or www. without protocol → https://
  if (/^(www\.)?[a-z0-9.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(s)) {
    const withProto = `https://${s.replace(/^\/+/, '')}`;
    return sanitizeUrl(withProto, 2000) || withProto.slice(0, 2000);
  }

  // Internal app path only if it does NOT look like a URL
  if (s.startsWith('/') && !s.startsWith('//') && !s.includes('<') && s.length <= 300) {
    // still guard: /youtube.com/... should become external
    const withoutSlash = s.replace(/^\/+/, '');
    if (/^(www\.)?[a-z0-9.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(withoutSlash)) {
      const withProto = `https://${withoutSlash}`;
      return sanitizeUrl(withProto, 2000) || withProto.slice(0, 2000);
    }
    if (/^https?:\/\//i.test(withoutSlash)) {
      return safePathOrUrl(withoutSlash);
    }
    return s;
  }

  const cleaned = sanitizeUrl(s, 2000);
  if (cleaned) return cleaned;
  return '/';
}

const CTA_STYLES = new Set(['primary', 'secondary', 'outline', 'amber', 'dark']);

function sanitizeCta(input, fallback = {}, index = 0) {
  const src = input && typeof input === 'object' ? input : {};
  const styleRaw = String(src.style || fallback.style || (index === 0 ? 'primary' : index === 1 ? 'secondary' : 'outline')).toLowerCase();
  const style = CTA_STYLES.has(styleRaw) ? styleRaw : 'outline';
  const label = sanitizeText(src.label, 80) || sanitizeText(fallback.label, 80) || '';
  return {
    id: sanitizeText(src.id, 40) || fallback.id || `cta-${index + 1}`,
    label,
    to: safePathOrUrl(src.to || fallback.to || '/'),
    style,
    enabled: src.enabled === false ? false : true,
  };
}

function sanitizeSlide(item, index) {
  const src = item && typeof item === 'object' ? item : {};
  const image =
    sanitizeUrl(src.image_url || src.image || '') ||
    sanitizeText(src.image_url || src.image || '', 2000);
  return {
    id: sanitizeText(src.id, 40) || `slide-${index + 1}`,
    image_url: image || '',
    title: sanitizeText(src.title, 120),
    link: safePathOrUrl(src.link || src.to || ''),
    enabled: src.enabled === false ? false : true,
  };
}

function sanitizeQuickLink(item) {
  const src = item && typeof item === 'object' ? item : {};
  return {
    label: sanitizeText(src.label, 80) || 'رابط',
    to: safePathOrUrl(src.to || src.link || '/'),
  };
}

export function sanitizeHeader(input) {
  const src = input && typeof input === 'object' ? input : {};
  const pointsRaw = Array.isArray(src.side_points) ? src.side_points : DEFAULT_HEADER.side_points;
  const points = pointsRaw
    .slice(0, 8)
    .map((p) => sanitizeText(p, 120))
    .filter(Boolean);

  const slidesRaw = Array.isArray(src.slides) ? src.slides : [];
  const slides = slidesRaw
    .slice(0, 12)
    .map((s, i) => sanitizeSlide(s, i))
    .filter((s) => s.image_url);

  const linksRaw = Array.isArray(src.quick_links) ? src.quick_links : [];
  const quick_links = linksRaw
    .slice(0, 12)
    .map(sanitizeQuickLink)
    .filter((l) => l.label);

  const cleanImg = (v) =>
    sanitizeUrl(v || '') || sanitizeText(v || '', 2000) || '';

  const featured = cleanImg(src.featured_image);
  const background = cleanImg(src.background_image);
  const background_tablet = cleanImg(src.background_image_tablet);
  const background_mobile = cleanImg(src.background_image_mobile);

  const posRaw = String(src.background_position || 'center').toLowerCase().trim();
  const allowedPos = new Set([
    'center',
    'top',
    'bottom',
    'left',
    'right',
    'center top',
    'center bottom',
    'left center',
    'right center',
  ]);
  const background_position = allowedPos.has(posRaw) ? posRaw : 'center';

  // CTAs: prefer full list; else migrate from primary/secondary
  let ctas = [];
  if (Array.isArray(src.ctas) && src.ctas.length) {
    ctas = src.ctas
      .slice(0, 12)
      .map((c, i) => sanitizeCta(c, {}, i))
      .filter((c) => c.label);
  } else {
    const p = sanitizeCta(src.primary_cta, DEFAULT_HEADER.primary_cta, 0);
    const s = sanitizeCta(src.secondary_cta, DEFAULT_HEADER.secondary_cta, 1);
    ctas = [p, s].filter((c) => c.label);
  }
  if (!ctas.length) {
    ctas = DEFAULT_HEADER.ctas.map((c, i) => sanitizeCta(c, c, i));
  }

  // Keep legacy fields in sync with first two CTAs
  const primary_cta = {
    label: ctas[0]?.label || DEFAULT_HEADER.primary_cta.label,
    to: ctas[0]?.to || DEFAULT_HEADER.primary_cta.to,
    style: ctas[0]?.style || 'primary',
  };
  const secondary_cta = {
    label: ctas[1]?.label || '',
    to: ctas[1]?.to || '/',
    style: ctas[1]?.style || 'secondary',
  };

  return {
    enabled: src.enabled === false ? false : true,
    badge: sanitizeText(src.badge, 120) || DEFAULT_HEADER.badge,
    title: sanitizeText(src.title, 120) || DEFAULT_HEADER.title,
    subtitle: sanitizeText(src.subtitle, 160) || '',
    description: sanitizeText(src.description, 600) || '',
    primary_cta,
    secondary_cta,
    ctas,
    side_enabled: src.side_enabled === false ? false : true,
    side_name: sanitizeText(src.side_name, 80) || DEFAULT_HEADER.side_name,
    side_role: sanitizeText(src.side_role, 120) || '',
    side_initials: sanitizeText(src.side_initials, 4) || 'SA',
    side_points: points.length ? points : DEFAULT_HEADER.side_points,
    show_stats: src.show_stats === false ? false : true,
    background_image: background,
    background_image_tablet: background_tablet,
    background_image_mobile: background_mobile,
    background_position,
    featured_image: featured,
    slides,
    quick_links,
  };
}

async function readHomepageImage() {
  try {
    const { data } = await supabase
      .from('settings')
      .select('value')
      .eq('key', HOMEPAGE_IMAGE_KEY)
      .maybeSingle();
    return String(data?.value || '').trim();
  } catch {
    return '';
  }
}

async function writeHomepageImage(url) {
  const value = String(url || '').trim();
  const { data: existing } = await supabase
    .from('settings')
    .select('key')
    .eq('key', HOMEPAGE_IMAGE_KEY)
    .maybeSingle();
  if (existing) {
    await supabase.from('settings').update({ value }).eq('key', HOMEPAGE_IMAGE_KEY);
  } else {
    await supabase.from('settings').insert({ key: HOMEPAGE_IMAGE_KEY, value });
  }
}

async function readHeader() {
  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .eq('key', HEADER_KEY)
    .maybeSingle();
  if (error) throw error;

  let parsed = null;
  if (data?.value) {
    try {
      parsed = typeof data.value === 'string' ? JSON.parse(data.value) : data.value;
    } catch {
      parsed = null;
    }
  }

  const header = sanitizeHeader(parsed || DEFAULT_HEADER);
  // Prefer explicit featured_image; else legacy homepage_image
  if (!header.featured_image) {
    const legacy = await readHomepageImage();
    if (legacy) header.featured_image = legacy;
  }
  return header;
}

async function writeHeader(body) {
  const clean = sanitizeHeader(body || {});
  const value = JSON.stringify(clean);
  const { data: existing } = await supabase
    .from('settings')
    .select('key')
    .eq('key', HEADER_KEY)
    .maybeSingle();
  if (existing) {
    const { error } = await supabase.from('settings').update({ value }).eq('key', HEADER_KEY);
    if (error) throw error;
  } else {
    const { error } = await supabase.from('settings').insert({ key: HEADER_KEY, value });
    if (error) throw error;
  }
  // Keep legacy key in sync so older clients still work
  try {
    await writeHomepageImage(clean.featured_image || '');
  } catch (err) {
    console.error('[header] homepage_image sync failed:', err?.message || err);
  }
  return clean;
}

export default async function handler(req, res) {
  if (handleOptions(req, res)) return;

  const rl = rateLimit(req, { key: 'header', limit: 80, windowMs: 60_000 });
  if (!rl.ok) return rejectRateLimit(res, rl.retryAfter);

  try {
    if (req.method === 'GET') {
      const header = await readHeader();
      return res.status(200).json(header);
    }

    if (req.method === 'PUT' || req.method === 'POST') {
      const admin = await requireAdmin(req, res);
      if (!admin) return;
      const header = await writeHeader(req.body || {});
      return res.status(200).json(header);
    }

    return methodNotAllowed(res);
  } catch (err) {
    return serverError(res, err, 'header');
  }
}
